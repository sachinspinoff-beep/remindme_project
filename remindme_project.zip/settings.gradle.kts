rootProject.name = "RemindMe"
include(":app")
