# RemindMe - Android project (Kotlin)

Features:
- Add reminders by text or voice (speech-to-text).
- Pick date & time for reminders.
- Local storage using Room.
- Schedules alarms with AlarmManager and shows text-only notifications.
- No network required.

How to build APK locally:
1. Open this folder in Android Studio.
2. Let Gradle sync and install required SDKs.
3. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
4. APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

Or build from command line (requires Android SDK + PATH):
```
./gradlew assembleDebug
```

Notes:
- This sample is minimal and intended as a starting point. You may need to add icons and polish UI.
- For voice input, grant microphone permission when prompted.
