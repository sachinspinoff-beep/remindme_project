package com.example.remindme

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface ReminderDao {
    @Insert
    suspend fun insert(reminder: Reminder): Long

    @Query("SELECT * FROM Reminder ORDER BY timeMillis ASC")
    suspend fun getAll(): List<Reminder>
}
