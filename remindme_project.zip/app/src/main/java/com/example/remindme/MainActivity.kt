package com.example.remindme

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private lateinit var adapter: ReminderAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = AppDatabase.getDatabase(this)

        val edtText = findViewById<EditText>(R.id.edtText)
        val btnAdd = findViewById<Button>(R.id.btnAdd)
        val btnVoice = findViewById<Button>(R.id.btnVoice)
        val btnPick = findViewById<Button>(R.id.btnPick)
        val rv = findViewById<RecyclerView>(R.id.rv)
        adapter = ReminderAdapter(listOf()) { reminder ->
            // On click: show details (no voice)
            Toast.makeText(this, reminder.text, Toast.LENGTH_SHORT).show()
        }
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        loadReminders()

        btnAdd.setOnClickListener {
            val text = edtText.text.toString().trim()
            if (text.isEmpty()) {
                Toast.makeText(this, "Enter reminder text", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            pickDateTimeAndSave(text)
        }

        btnVoice.setOnClickListener {
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                Toast.makeText(this, "Speech recognition not available", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                return@setOnClickListener
            }
            startVoiceInput()
        }

        btnPick.setOnClickListener {
            pickDateTimeAndSave(edtText.text.toString().trim())
        }
    }

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            Toast.makeText(this, "Microphone permission required for voice input", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your reminder")
        try {
            startActivityForResult(intent, REQUEST_VOICE)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start voice intent", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_VOICE && resultCode == RESULT_OK) {
            val matches = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (!matches.isNullOrEmpty()) {
                val spoken = matches[0]
                // Ask for time then save
                pickDateTimeAndSave(spoken)
            }
        }
    }

    private fun pickDateTimeAndSave(text: String) {
        if (text.isEmpty()) {
            Toast.makeText(this, "Enter reminder text first", Toast.LENGTH_SHORT).show()
            return
        }
        val now = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            TimePickerDialog(this, { _, hour, minute ->
                val cal = Calendar.getInstance()
                cal.set(y, m, d, hour, minute, 0)
                saveReminder(text, cal.timeInMillis)
            }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), false).show()
        }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun saveReminder(text: String, timeMillis: Long) {
        val reminder = Reminder(0, text, timeMillis, false)
        CoroutineScope(Dispatchers.IO).launch {
            val id = db.reminderDao().insert(reminder)
            ReminderScheduler.schedule(this@MainActivity, id, timeMillis, text)
            withContext(Dispatchers.Main) {
                Toast.makeText(this@MainActivity, "Saved", Toast.LENGTH_SHORT).show()
                loadReminders()
            }
        }
    }

    private fun loadReminders() {
        CoroutineScope(Dispatchers.IO).launch {
            val list = db.reminderDao().getAll()
            withContext(Dispatchers.Main) {
                adapter.update(list)
            }
        }
    }

    companion object {
        const val REQUEST_VOICE = 1001
    }
}
