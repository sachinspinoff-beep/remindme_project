package com.example.remindme

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*

class ReminderAdapter(private var items: List<Reminder>, private val onClick: (Reminder)->Unit)
    : RecyclerView.Adapter<ReminderAdapter.VH>() {

    fun update(newItems: List<Reminder>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_reminder, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val r = items[position]
        holder.txt.text = r.text
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        holder.time.text = sdf.format(Date(r.timeMillis))
        holder.itemView.setOnClickListener { onClick(r) }
    }

    override fun getItemCount(): Int = items.size

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val txt: TextView = view.findViewById(R.id.txt)
        val time: TextView = view.findViewById(R.id.time)
    }
}
